package com.example.menuexamen;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import java.io.IOException;
import java.time.LocalDate;

public class Listado {

    @FXML
    private TableView<Cliente> tablaClientes;
    @FXML
    private TableColumn<Cliente, String> colNombre;
    @FXML
    private TableColumn<Cliente, String> colApellidos;
    @FXML
    private TableColumn<Cliente, String> colDni;
    @FXML
    private TableColumn<Cliente, String> colTipo;
    @FXML
    private TableColumn<Cliente, Integer> colSesiones;
    @FXML
    private TableColumn<Cliente, LocalDate> colFechaAlta;
    @FXML
    private TableColumn<Cliente, LocalDate> colFechaNacimiento;
    @FXML
    private TableColumn<Cliente, Double> colPeso;
    @FXML
    private TableColumn<Cliente, Integer> colAltura;
    @FXML
    private ObservableList<Cliente> listaClientes = DatosCompartidos.getListaClientes();

    public void initialize() {
        tablaClientes.setItems(listaClientes);
        colNombre.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getNombre());
        });

        colApellidos.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getApellidos());
        });

        colDni.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getDni());
        });

        colDni.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getDni());
        });

        colTipo.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getTipo());
        });

        colSesiones.setCellValueFactory(cellData -> {
            return new SimpleIntegerProperty(cellData.getValue().getSesiones()).asObject();
        });

        colFechaAlta.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getFechaAlta())
        );
        colFechaNacimiento.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getFechaNacimiento())
        );
        colPeso.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getPeso())
        );
        colAltura.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getAltura())
        );
    }

    @FXML
    private void cerrar(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Cerrar");
        alert.setHeaderText(null);
        alert.setContentText("¿Está seguro de cerrar?");

        ButtonType buttonOK = new ButtonType("OK");
        ButtonType buttonCancel = new ButtonType("Cancelar");

        alert.getButtonTypes().setAll(buttonOK, buttonCancel);

        alert.showAndWait().ifPresent(response -> {
            if (response == buttonOK) {
                System.out.println("Se ha cerrado correctamente");
                System.exit(0);
            } else {
                System.out.println("Se canceló el cierre");
            }
        });
    }
}

