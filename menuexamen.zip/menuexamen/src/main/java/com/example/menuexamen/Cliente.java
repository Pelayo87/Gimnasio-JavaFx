package com.example.menuexamen;

import java.io.Serializable;
import java.time.LocalDate;

public class Cliente implements Serializable{
    private String nombre;
    private String apellidos;
    private String dni;
    private String tipo;
    private int sesiones;
    private LocalDate fechaAlta;
    private LocalDate fechaNacimiento;
    private double peso;
    private int altura;

    public Cliente(String nombre, String apellidos, String dni, String tipo, int sesiones, String fechaAlta, String fechaNacimiento, double peso, int altura) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.tipo = tipo;
        this.sesiones = sesiones;
        this.fechaAlta = LocalDate.parse(fechaAlta);
        this.fechaNacimiento = LocalDate.parse(fechaNacimiento);
        this.peso = peso;
        this.altura = altura;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getSesiones() {
        return sesiones;
    }

    public void setSesiones(int sesiones) {
        this.sesiones = sesiones;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", dni='" + dni + '\'' +
                ", tipo='" + tipo + '\'' +
                ", sesiones=" + sesiones +
                ", fechaAlta=" + fechaAlta +
                ", fechaNacimiento=" + fechaNacimiento +
                ", peso=" + peso +
                ", altura=" + altura +
                '}';
    }
}
