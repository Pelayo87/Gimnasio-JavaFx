package com.example.menuexamen;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {
    @FXML
    private AnchorPane anchorCuerpo;
    @FXML
    private ObservableList<Cliente> listaClientes = DatosCompartidos.getListaClientes();

    @FXML
    public void alta(ActionEvent event) throws IOException {
        AnchorPane altaPane = FXMLLoader.load(getClass().getResource("ventana-alta.fxml"));
        anchorCuerpo.getChildren().setAll(altaPane);
        tituloalta((Stage) anchorCuerpo.getScene().getWindow());
    }

    public void tituloalta(Stage stage){
        stage.setTitle("ALTA DE CLIENTE");
    }
    @FXML
    public void baja(ActionEvent event) throws IOException {
        AnchorPane bajaPane = FXMLLoader.load(getClass().getResource("ventana-baja.fxml"));
        anchorCuerpo.getChildren().setAll(bajaPane);
        titulobaja((Stage) anchorCuerpo.getScene().getWindow());
    }
    public void titulobaja(Stage stage){
        stage.setTitle("BAJA DE CLIENTE");
    }

    @FXML
    public void listado(ActionEvent event) throws IOException {
        AnchorPane listadoPane = FXMLLoader.load(getClass().getResource("listado.fxml"));
        anchorCuerpo.getChildren().setAll(listadoPane);
        titulolistado((Stage) anchorCuerpo.getScene().getWindow());
    }
    public void titulolistado(Stage stage){
        stage.setTitle("CLIENTES");
    }

    @FXML
    public void ayuda(ActionEvent event) throws IOException {
        AnchorPane ayudaPane = FXMLLoader.load(getClass().getResource("ayuda.fxml"));
        anchorCuerpo.getChildren().setAll(ayudaPane);
        tituloayuda((Stage) anchorCuerpo.getScene().getWindow());
    }
    public void tituloayuda(Stage stage){
        stage.setTitle("Ayuda");
    }

    @FXML
    public void sesiones(ActionEvent event) throws IOException {
        AnchorPane ayudaPane = FXMLLoader.load(getClass().getResource("sesiones.fxml"));
        anchorCuerpo.getChildren().setAll(ayudaPane);
        titulosesiones((Stage) anchorCuerpo.getScene().getWindow());
    }
    public void titulosesiones(Stage stage){
        stage.setTitle("Sesiones");
    }

    @FXML
    public void edades(ActionEvent event) throws IOException {
        AnchorPane ayudaPane = FXMLLoader.load(getClass().getResource("edades.fxml"));
        anchorCuerpo.getChildren().setAll(ayudaPane);
        tituloedades((Stage) anchorCuerpo.getScene().getWindow());
    }
    public void tituloedades(Stage stage){
        stage.setTitle("Edades");
    }

    @FXML
    private void cerrar(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Cerrar");
        alert.setHeaderText(null);
        alert.setContentText("¿Está seguro de cerrar?");

        ButtonType buttonOK = new ButtonType("OK");
        ButtonType buttonCancel = new ButtonType("Cancelar");

        alert.getButtonTypes().setAll(buttonOK, buttonCancel);

        alert.showAndWait().ifPresent(response -> {
            if (response == buttonOK) {
                System.out.println("Se ha cerrado correctamente");
                System.exit(0);
            } else {
                System.out.println("Se canceló el cierre");
            }
        });
    }
}
