package com.example.menuexamen;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DatosCompartidos {
    private static final ObservableList<Cliente> listaClientes = FXCollections.observableArrayList();

    public static ObservableList<Cliente> getListaClientes() {
        return listaClientes;
    }
}
