package com.example.menuexamen;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class Ayuda{
    @FXML
    private TextArea infoTextArea;

    @FXML
    private void initialize() {
        infoTextArea.setEditable(false);
    }

    @FXML
    private void TextAreaClick(MouseEvent event) {
        //Stage stage = (Stage) infoTextArea.getScene().getWindow();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Message");
        alert.setHeaderText(null);
        alert.setContentText("No está permitido editar");
        alert.showAndWait();
    }
}
