package com.example.menuexamen;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class Edades implements Initializable {
    @FXML
    private LineChart<String, Number> lineChart;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        lineChart.setTitle("Edad de los Clientes");

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Edad");

        for (Cliente cliente : DatosCompartidos.getListaClientes()) {
            String fechaNacimientoStr = cliente.getFechaNacimiento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            int edad = calcularEdad(cliente.getFechaNacimiento());
            series.getData().add(new XYChart.Data<>(fechaNacimientoStr, edad));
        }

        lineChart.getData().add(series);
    }

    private int calcularEdad(LocalDate fechaNacimiento) {
        LocalDate fechaActual = LocalDate.now();
        return fechaActual.getYear() - fechaNacimiento.getYear();
    }
}


