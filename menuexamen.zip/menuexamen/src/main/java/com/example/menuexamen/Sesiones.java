package com.example.menuexamen;

import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Sesiones {

    @FXML
    private PieChart pieChart;

    public void initialize() {
        int totalClientes = DatosCompartidos.getListaClientes().size();
        int sesionesClasico = 0;
        int sesionesMaquina = 0;
        int sesionesWinsor = 0;

        for (Cliente cliente : DatosCompartidos.getListaClientes()) {
            String tipo = cliente.getTipo();
            switch (tipo) {
                case "Clásico":
                    sesionesClasico += cliente.getSesiones();
                    break;
                case "Máquina":
                    sesionesMaquina += cliente.getSesiones();
                    break;
                case "Winsor":
                    sesionesWinsor += cliente.getSesiones();
                    break;
            }
        }

        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Clásico", sesionesClasico),
                new PieChart.Data("Máquina", sesionesMaquina),
                new PieChart.Data("Winsor", sesionesWinsor)
        );

        pieChart.setData(pieChartData);
        pieChart.setTitle("Proporción de Sesiones");
    }
}
