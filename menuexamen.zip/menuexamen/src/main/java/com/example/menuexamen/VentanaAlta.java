package com.example.menuexamen;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;

public class VentanaAlta {
    @FXML
    private TextField nombreTextField;

    @FXML
    private TextField apellidosTextField;

    @FXML
    private TextField dniTextField;

    @FXML
    private RadioButton clasicoRadioButton;

    @FXML
    private RadioButton maquinaRadioButton;

    @FXML
    private RadioButton winsorRadioButton;

    @FXML
    private Spinner<Integer> sesionesSpinner;

    @FXML
    private DatePicker altaDatePicker;

    @FXML
    private Slider pesoSlider;

    @FXML
    private Spinner<Integer> alturaSpinner;

    @FXML
    private DatePicker nacimientoDatePicker;
    @FXML
    private ObservableList<Cliente> listaClientes = DatosCompartidos.getListaClientes();

    @FXML
    public void initialize() {
        //AGRUPO LOS RADIOBUTTONS  PARA QUE SOLO PUEDA ELEGIRSE UNA OPCIÓN
        ToggleGroup tipoToggleGroup = new ToggleGroup();
        clasicoRadioButton.setToggleGroup(tipoToggleGroup);
        maquinaRadioButton.setToggleGroup(tipoToggleGroup);
        winsorRadioButton.setToggleGroup(tipoToggleGroup);

        //APLICO VALORES A LOS SPINNER PARA QUE SE PUEDAN USAR, SINO NO SON INTERACTUABLES AL EJECUTAR EL PROGRAMA
        SpinnerValueFactory<Integer> sesionesValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100);
        sesionesSpinner.setValueFactory(sesionesValueFactory);
        sesionesSpinner.setEditable(true);

        SpinnerValueFactory<Integer> alturaValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 300);
        alturaSpinner.setValueFactory(alturaValueFactory);
        alturaSpinner.setEditable(true);

        //SLIDER DE PESO CON INTERVALO DE 50 A 120
        pesoSlider.setMin(50);
        pesoSlider.setMax(120);
        pesoSlider.setValue(5);
        pesoSlider.setMajorTickUnit(1);
        pesoSlider.setMinorTickCount(0);
        pesoSlider.setSnapToTicks(true);

        //MUESTRO LAS ETIQUETAS DEL SLIDER PARA QUE SEAN VISIBLES
        pesoSlider.setShowTickLabels(true);
    }

    @FXML
    private void alta(ActionEvent event) throws IOException {
        String nombre = nombreTextField.getText();
        String apellidos = apellidosTextField.getText();
        String dni = dniTextField.getText();

        if (nombre.isEmpty() && apellidos.isEmpty() && dni.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Tienes campos sin rellenar.");
            alert.showAndWait();
            return;
        } else if (nombre.isEmpty() && apellidos.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Tienes campos sin rellenar. No has introducido el campo del nombre ni de los apellidos.");
            alert.showAndWait();
            return;
        } else if (nombre.isEmpty() && dni.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Tienes campos sin rellenar. No has introducido el campo del nombre ni del DNI.");
            alert.showAndWait();
            return;
        } else if (apellidos.isEmpty() && dni.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Tienes campos sin rellenar. No has introducido el campo de los apellidos ni del DNI.");
            alert.showAndWait();
            return;
        } else if (nombre.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("No has introducido el campo del nombre.");
            alert.showAndWait();
            return;
        } else if (apellidos.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("No has introducido el campo de los apellidos.");
            alert.showAndWait();
            return;
        } else if (dni.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("No has introducido el campo del DNI.");
            alert.showAndWait();
            return;
        }

        // Validación del formato del DNI
        if (!dni.matches("\\d{8}[a-zA-Z]")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("El DNI debe tener 8 números seguidos de una letra");
            alert.showAndWait();
            return;
        }

        String tipo = "";

        if (clasicoRadioButton.isSelected()) {
            tipo = "Clásico";
        } else if (maquinaRadioButton.isSelected()) {
            tipo = "Máquina";
        } else if (winsorRadioButton.isSelected()) {
            tipo = "Winsor";
        }

        if (tipo.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Debes seleccionar un tipo.");
            alert.showAndWait();
            return;
        }

        int sesiones = sesionesSpinner.getValue();

        if (sesiones <= 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("El número de sesiones debe ser mayor que cero.");
            alert.showAndWait();
            return;
        }

        LocalDate ValorfechaAlta = altaDatePicker.getValue();
        LocalDate ValorfechaNacimiento = nacimientoDatePicker.getValue();
        LocalDate fechaActual = LocalDate.now();

        if (ValorfechaAlta == null || ValorfechaNacimiento == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Debes seleccionar fechas válidas.");
            alert.showAndWait();
            return;
        } else if (ValorfechaAlta.isAfter(fechaActual) || ValorfechaNacimiento.isAfter(fechaActual)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Debes seleccionar fechas válidas y anteriores a la fecha actual.");
            alert.showAndWait();
            return;
        }

        String fechaAlta = ValorfechaAlta.toString();
        String fechaNacimiento = ValorfechaNacimiento.toString();


        double peso = pesoSlider.getValue();

        if (peso <= 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("El peso debe ser mayor que cero.");
            alert.showAndWait();
            return;
        }

        int altura = alturaSpinner.getValue();

        if (altura <= 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("La altura debe ser mayor que cero.");
            alert.showAndWait();
            return;
        }

        Cliente nuevoCliente = new Cliente(nombre,apellidos,dni,tipo,sesiones,fechaAlta,fechaNacimiento,peso,altura);

        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
        confirmacion.setTitle("Confirmación");
        confirmacion.setHeaderText(null);
        confirmacion.setContentText("¿Estás seguro de dar de alta a este cliente?");

        ButtonType resultado = confirmacion.showAndWait().orElse(ButtonType.CANCEL);

        if (resultado == ButtonType.OK) {
            listaClientes.add(nuevoCliente);

            mostrarMensaje("Datos guardados", "Los datos se han guardado correctamente.");
        }

        System.out.println("DATOS DEL CLIENTE:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellidos: " + apellidos);
        System.out.println("DNI: " + dni);
        System.out.println("Tipo: " + tipo);
        System.out.println("Sesiones: " + sesiones);
        System.out.println("Fecha de Alta: " + fechaAlta);
        System.out.println("Fecha de Nacimiento: " + fechaNacimiento);
        System.out.println("Peso: " + peso);
        System.out.println("Altura: " + altura);
    }

    private void mostrarMensaje(String titulo, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(contenido);
        alert.showAndWait();
    }


    @FXML
    private void reset() {
        nombreTextField.clear();
        apellidosTextField.clear();
        dniTextField.clear();
        clasicoRadioButton.setSelected(false);
        maquinaRadioButton.setSelected(false);
        winsorRadioButton.setSelected(false);
        sesionesSpinner.getValueFactory().setValue(0);
        altaDatePicker.setValue(null);
        pesoSlider.setValue(0);
        alturaSpinner.getValueFactory().setValue(0);
        nacimientoDatePicker.setValue(null);
    }
}
