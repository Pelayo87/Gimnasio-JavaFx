package com.example.menuexamen;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;

public class VentanaBaja {

    @FXML
    private TextField txtDni;
    @FXML
    private Button btnBaja;
    @FXML
    private Button btnLimpiar;
    @FXML
    private ObservableList<Cliente> listaClientes = DatosCompartidos.getListaClientes();

    @FXML
    private void eliminarCliente() {
        String dni = txtDni.getText();

        Cliente eliminarCliente = null;
        for (Cliente c : listaClientes) {
            if (c.getDni().equals(dni)) {
                eliminarCliente = c;
                break;
            }
        }

        if (eliminarCliente != null) {
            Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
            confirmacion.setTitle("Confirmación");
            confirmacion.setHeaderText(null);
            confirmacion.setContentText("¿Estás seguro de eliminar este cliente?");

            ButtonType resultado = confirmacion.showAndWait().orElse(ButtonType.CANCEL);

            if (resultado == ButtonType.OK) {
                listaClientes.remove(eliminarCliente);
                mostrarMensaje("Cliente eliminado correctamente.");
            }
        } else {
            mostrarMensaje("No se encontró ningún cliente con el DNI especificado.");
        }
    }


    private void mostrarMensaje(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void limpiar(){
        txtDni.clear();
    }

}
