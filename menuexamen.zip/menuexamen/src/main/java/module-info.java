module com.example.menuexamen {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.menuexamen to javafx.fxml;
    exports com.example.menuexamen;
}